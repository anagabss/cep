# Consulta Cep

Projeto simples criado em Angular v 14.2.8.

## Você pode acessar o site do projeto Consulta Cep

https://consulta-cep-via-cep.vercel.app/

## Layout App

![Web](https://github.com/joaocairiton/assets/blob/main/image%20Cep/cepfoto.PNG)

## Tecnologias utilizadas

Angular versão 14.2.8

## API externa

https://viacep.com.br/

## Autor 

https://www.linkedin.com/in/joaocairiton/

